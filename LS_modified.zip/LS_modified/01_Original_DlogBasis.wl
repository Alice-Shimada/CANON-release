(* Original recursive LeadingSingularities implementation.

   Canonical source:
   /home/wuyu/package/DlogBasis-master/DlogBasis.wl

   Public entry points after loading:
     DlogBasis`LeadingSingularities[func, vars]
     DlogBasis`LeadingSingularities[func, vars, coefficientHead]
*)

If[! MemberQ[$Packages, "DlogBasis`"],
  Get["/home/wuyu/package/DlogBasis-master/DlogBasis.wl"]
];

