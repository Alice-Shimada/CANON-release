(* Current version: Singular fast path, positive-dimensional GTZ
   primary/prime decomposition, and cached recursive fallback.

   This loader uses the same canonical hybrid implementation as version 03.
   The distinguishing option is PrimeDecomposition -> True (the default).

   Additional public entry point:
     SimultaneousDlogResidues`SingularPrimaryDecomposition[
       divisors, vars]
*)

Get[FileNameJoin[{
  DirectoryName[DirectoryName[$InputFileName]],
  "DlogBasisLeadingSingularitiesSingular.wl"
}]];

Options[LeadingSingularitiesPrimeDecomposition] =
  Options[DlogBasisLeadingSingularitiesSingular`LeadingSingularitiesSingular];

LeadingSingularitiesPrimeDecomposition[
    func_, vars_List, head_ /; ! MatchQ[head, _Rule | _RuleDelayed],
    OptionsPattern[]] :=
  DlogBasisLeadingSingularitiesSingular`LeadingSingularitiesSingular[
    func, vars, head,
    DlogBasisLeadingSingularitiesSingular`CutDivisors ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`CutDivisors],
    DlogBasisLeadingSingularitiesSingular`CompletionDivisors ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`CompletionDivisors],
    DlogBasisLeadingSingularitiesSingular`BlockVariables ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`BlockVariables],
    MonomialOrder -> OptionValue[MonomialOrder],
    DlogBasisLeadingSingularitiesSingular`MaxCompletions ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`MaxCompletions],
    DlogBasisLeadingSingularitiesSingular`PrimeDecomposition -> True,
    DlogBasisLeadingSingularitiesSingular`VerifyFastPath ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`VerifyFastPath]
  ];

LeadingSingularitiesPrimeDecomposition[
    func_, vars_List, OptionsPattern[]] :=
  DlogBasisLeadingSingularitiesSingular`LeadingSingularitiesSingular[
    func, vars,
    DlogBasisLeadingSingularitiesSingular`CutDivisors ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`CutDivisors],
    DlogBasisLeadingSingularitiesSingular`CompletionDivisors ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`CompletionDivisors],
    DlogBasisLeadingSingularitiesSingular`BlockVariables ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`BlockVariables],
    MonomialOrder -> OptionValue[MonomialOrder],
    DlogBasisLeadingSingularitiesSingular`MaxCompletions ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`MaxCompletions],
    DlogBasisLeadingSingularitiesSingular`PrimeDecomposition -> True,
    DlogBasisLeadingSingularitiesSingular`VerifyFastPath ->
      OptionValue[DlogBasisLeadingSingularitiesSingular`VerifyFastPath]
  ];
