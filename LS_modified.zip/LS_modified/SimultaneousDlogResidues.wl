(* ::Package:: *)
BeginPackage["SimultaneousDlogResidues`"];
$SingularExecutable::usage = "Path to the Singular executable.";
SingularIdealDimension::usage = "SingularIdealDimension[divisors,vars] computes ideal dimension with Singular.";
SingularPrimaryDecomposition::usage = "SingularPrimaryDecomposition[divisors,vars] computes cached GTZ primary decomposition data. Each component contains its primary ideal, associated prime, and dimension.";
FindZeroDimensionalCompletions::usage = "FindZeroDimensionalCompletions[base,candidates,vars] finds minimal subsets making the cut zero-dimensional.";
PrepareDlogCut::usage = "PrepareDlogCut[divisors,vars] caches a Singular standard basis and Jacobian normal form.";
SimultaneousDlogConditions::usage = "SimultaneousDlogConditions[N,cut] imposes NF(N-r J)=0 using Singular.";
SimultaneousDlogSolve::usage = "SimultaneousDlogSolve[N,cut,parameters] solves the dlog equations.";
DlogNumerator::usage = "DlogNumerator[cut] returns det(d fi/d zj).";
SingularLiftCertificate::usage = "SingularLiftCertificate[N,cut] uses Singular module lift to certify N belongs to <f1,...,fn,J>.";
Begin["`Private`"];

$SingularExecutable = "/usr/local/bin/Singular";
$singularCache = <||>;
PrepareDlogCut::dim = "A point residue needs as many divisors (`1`) as block variables (`2`).";
PrepareDlogCut::nz = "The supplied cut has Singular dimension `1`, not zero.";
PrepareDlogCut::sing = "Singular failed: `1`";
SingularIdealDimension::sing = "Singular failed: `1`";
SimultaneousDlogConditions::cut = "The second argument is not valid Singular cut data.";

markerValue[text_, tag_] := Module[{hit},
  hit = StringCases[text, tag <> "_BEGIN\n" ~~
    x : Shortest[__] ~~ "\n" <> tag <> "_END" :> StringTrim[x]];
  If[hit === {}, Missing["NotFound", tag], First[hit]]
];
markerValues[text_, tag_] :=
  StringCases[text, tag <> "_BEGIN\n" ~~ x : Shortest[__] ~~
    "\n" <> tag <> "_END" :> StringTrim[x]];
symbolsIn[expr_] := DeleteDuplicates@Variables[Flatten@{expr}];
safeNames[n_, prefix_] := Table[prefix <> ToString[i], {i, n}];
singularString[expr_, vars_List, params_List] := Module[{rules},
  rules = Join[Thread[vars -> (Symbol /@ safeNames[Length[vars], "v"])],
    Thread[params -> (Symbol /@ safeNames[Length[params], "p"])]];
  ToString[InputForm[Expand[expr /. rules]]]
];
runSingular[script_String] := Module[{file, proc},
  file = FileNameJoin[{$TemporaryDirectory,
    "dlog-singular-" <> CreateUUID[] <> ".sing"}];
  Export[file, script, "Text"];
  proc = RunProcess[{$SingularExecutable, "-q", file}];
  Quiet@DeleteFile[file];
  If[proc["ExitCode"] =!= 0,
    Failure["Singular", <|"StandardError" -> proc["StandardError"],
      "StandardOutput" -> proc["StandardOutput"]|>], proc["StandardOutput"]]
];
ringDeclaration[vars_List, params_List, order_String] :=
  "ring dlogRing=" <> If[params === {}, "0", "(0," <>
    StringRiffle[safeNames[Length[params], "p"], ","] <> ")"] <>
  ",(" <> StringRiffle[safeNames[Length[vars], "v"], ","] <> ")," <>
  order <> ";\n";

Options[SingularIdealDimension] = {MonomialOrder -> "dp"};
SingularIdealDimension[divisors_List, vars_List, OptionsPattern[]] := Module[
  {params, script, out, value, key},
  key = HoldComplete["Dimension", divisors, vars, OptionValue[MonomialOrder]];
  If[KeyExistsQ[$singularCache, key], Return[$singularCache[key]]];
  params = Complement[symbolsIn[divisors], vars];
  script = ringDeclaration[vars, params, OptionValue[MonomialOrder]] <>
    "ideal I=" <> StringRiffle[singularString[#, vars, params] & /@ divisors, ","] <>
    ";\nideal G=std(I);\nprint(\"DIM_BEGIN\");print(dim(G));print(\"DIM_END\");\nquit;\n";
  out = runSingular[script];
  If[FailureQ[out], Message[SingularIdealDimension::sing, out]; Return[$Failed]];
  value = ToExpression@markerValue[out, "DIM"];
  AssociateTo[$singularCache, key -> value]; value
];

Options[SingularPrimaryDecomposition] = {MonomialOrder -> "dp"};
SingularPrimaryDecomposition[divisors_List, vars_List, OptionsPattern[]] :=
 Module[{params, script, out, blocks, reverseRules, parseIdeal, key, result},
  key = HoldComplete["PrimaryDecomposition", divisors, vars,
    OptionValue[MonomialOrder]];
  If[KeyExistsQ[$singularCache, key], Return[$singularCache[key]]];
  params = Complement[symbolsIn[divisors], vars];
  script = "LIB \"primdec.lib\";\n" <>
    ringDeclaration[vars, params, OptionValue[MonomialOrder]] <>
    "ideal I=" <>
    StringRiffle[singularString[#, vars, params] & /@ divisors, ","] <>
    ";\nlist D=primdecGTZ(I);\n" <>
    "for (int i=1;i<=size(D);i++){" <>
    "print(\"COMPONENT_BEGIN\");" <>
    "print(\"DIM_BEGIN\");print(dim(std(D[i][2])));print(\"DIM_END\");" <>
    "print(\"PRIMARY_BEGIN\");print(string(D[i][1]));print(\"PRIMARY_END\");" <>
    "print(\"PRIME_BEGIN\");print(string(D[i][2]));print(\"PRIME_END\");" <>
    "print(\"COMPONENT_END\");}\nquit;\n";
  out = runSingular[script];
  If[FailureQ[out], Return[out]];
  reverseRules = Join[
    Thread[(Symbol /@ safeNames[Length[vars], "v"]) -> vars],
    Thread[(Symbol /@ safeNames[Length[params], "p"]) -> params]];
  parseIdeal[s_String] := If[StringTrim[s] === "0", {0},
    (ToExpression["{" <> StringReplace[StringTrim[s], "\n" -> ""] <> "}"] /.
      reverseRules)];
  blocks = markerValues[out, "COMPONENT"];
  result = Map[
    <|"Dimension" -> ToExpression@markerValue[#, "DIM"],
      "PrimaryIdeal" -> parseIdeal@markerValue[#, "PRIMARY"],
      "PrimeIdeal" -> parseIdeal@markerValue[#, "PRIME"]|> &, blocks];
  AssociateTo[$singularCache, key -> result];
  result
];

Options[FindZeroDimensionalCompletions] = {MonomialOrder -> "dp", MaxCompletions -> Infinity};
FindZeroDimensionalCompletions[base_List, candidates_List, vars_List,
    OptionsPattern[]] := Module[{dimension, needed, subsets, found = {}},
  dimension = SingularIdealDimension[base, vars,
    MonomialOrder -> OptionValue[MonomialOrder]];
  If[dimension === $Failed, Return[$Failed]];
  If[dimension == 0, Return[{{}}]];
  needed = Max[1, dimension];
  Do[
    subsets = Subsets[candidates, {k}];
    Do[If[SingularIdealDimension[Join[base, subset], vars,
        MonomialOrder -> OptionValue[MonomialOrder]] == 0,
      AppendTo[found, subset];
      If[Length[found] >= OptionValue[MaxCompletions], Return[found]]],
      {subset, subsets}];
    If[found =!= {}, Return[found]], {k, needed, Length[candidates]}];
  found
];

Options[PrepareDlogCut] = {MonomialOrder -> "dp"};
PrepareDlogCut[divisors_List, vars_List, OptionsPattern[]] := Module[
  {params, jac, script, out, dim, gbString, jacString, reverseRules},
  If[Length[divisors] =!= Length[vars],
    Message[PrepareDlogCut::dim, Length[divisors], Length[vars]]; Return[$Failed]];
  params = Complement[symbolsIn[divisors], vars];
  jac = Factor@Det@Table[D[divisors[[i]], vars[[j]]],
    {i, Length[vars]}, {j, Length[vars]}];
  script = ringDeclaration[vars, params, OptionValue[MonomialOrder]] <>
    "ideal I=" <> StringRiffle[singularString[#, vars, params] & /@ divisors, ","] <>
    ";\nideal G=std(I);\nprint(\"DIM_BEGIN\");print(dim(G));print(\"DIM_END\");\n" <>
    "print(\"GB_BEGIN\");print(string(G));print(\"GB_END\");\npoly j=" <>
    singularString[jac, vars, params] <>
    ";\nprint(\"JNF_BEGIN\");print(string(reduce(j,G)));print(\"JNF_END\");\nquit;\n";
  out = runSingular[script];
  If[FailureQ[out], Message[PrepareDlogCut::sing, out]; Return[$Failed]];
  dim = ToExpression@markerValue[out, "DIM"];
  If[dim =!= 0, Message[PrepareDlogCut::nz, dim]; Return[$Failed]];
  gbString = markerValue[out, "GB"]; jacString = markerValue[out, "JNF"];
  reverseRules = Join[Thread[(Symbol /@ safeNames[Length[vars], "v"]) -> vars],
    Thread[(Symbol /@ safeNames[Length[params], "p"]) -> params]];
  <|"Divisors" -> divisors, "Variables" -> vars, "Parameters" -> params,
    "Dimension" -> dim, "SingularBasis" -> gbString, "Jacobian" -> jac,
    "JacobianNormalForm" -> (ToExpression[jacString] /. reverseRules),
    "MonomialOrder" -> OptionValue[MonomialOrder], "Backend" -> "Singular"|>
];
DlogNumerator[cut_Association] := cut["Jacobian"];

singularReduce[poly_, cut_Association] := Module[
  {vars, allParams, script, out, nf, reverseRules},
  vars = cut["Variables"];
  allParams = DeleteDuplicates@Join[cut["Parameters"],
    Complement[symbolsIn[poly], vars]];
  script = ringDeclaration[vars, allParams, cut["MonomialOrder"]] <>
    "ideal G=" <> cut["SingularBasis"] <> ";\nG=std(G);\npoly h=" <>
    singularString[poly, vars, allParams] <>
    ";\nprint(\"NF_BEGIN\");print(string(reduce(h,G)));print(\"NF_END\");\nquit;\n";
  out = runSingular[script]; If[FailureQ[out], Return[out]];
  nf = markerValue[out, "NF"];
  reverseRules = Join[Thread[(Symbol /@ safeNames[Length[vars], "v"]) -> vars],
    Thread[(Symbol /@ safeNames[Length[allParams], "p"]) -> allParams]];
  ToExpression[nf] /. reverseRules
];

SingularLiftCertificate[poly_, cut_Association] := Module[
  {vars, allParams, generators, script, out, matrix, remainder},
  vars = cut["Variables"];
  allParams = DeleteDuplicates@Join[cut["Parameters"],
    Complement[symbolsIn[poly], vars]];
  generators = Join[cut["Divisors"], {cut["Jacobian"]}];
  script = ringDeclaration[vars, allParams, cut["MonomialOrder"]] <>
    "module M=" <> StringRiffle[
      ("[" <> singularString[#, vars, allParams] <> "]") & /@ generators,
      ","] <> ";\nmodule S=[" <>
    singularString[poly, vars, allParams] <> "];\n" <>
    "matrix T=lift(M,S);\nprint(\"LIFT_BEGIN\");print(string(T));" <>
    "print(\"LIFT_END\");\nmatrix R=matrix(S)-matrix(M)*T;\n" <>
    "print(\"REM_BEGIN\");print(string(R));print(\"REM_END\");\nquit;\n";
  out = runSingular[script];
  If[FailureQ[out], Return[out]];
  matrix = markerValue[out, "LIFT"];
  remainder = markerValue[out, "REM"];
  <|"Backend" -> "Singular", "Method" -> "module lift",
    "GeneratorOrder" -> Join[cut["Divisors"], {"Jacobian"}],
    "LiftMatrixRaw" -> matrix, "RemainderRaw" -> remainder,
    "Verified" -> MemberQ[{"0", "0,"}, StringTrim[remainder]]|>
];

Options[SimultaneousDlogConditions] = {ResidueSymbol -> Automatic};
SimultaneousDlogConditions[numerator_, cut_Association, OptionsPattern[]] :=
 Module[{vars, rho, numeratorNF, differenceNF, coefficients},
  If[Lookup[cut, "Backend", None] =!= "Singular",
    Message[SimultaneousDlogConditions::cut]; Return[$Failed]];
  vars = cut["Variables"];
  rho = Replace[OptionValue[ResidueSymbol], Automatic :> Unique["residue$"]];
  numeratorNF = Expand@singularReduce[numerator, cut];
  If[FailureQ[numeratorNF], Return[numeratorNF]];
  differenceNF = Expand@singularReduce[numerator - rho cut["Jacobian"], cut];
  If[FailureQ[differenceNF], Return[differenceNF]];
  coefficients = If[TrueQ[differenceNF === 0], {},
    Last /@ CoefficientRules[differenceNF, vars]];
  <|"ResidueSymbol" -> rho, "NumeratorNormalForm" -> numeratorNF,
    "DifferenceNormalForm" -> differenceNF,
    "Equations" -> Thread[DeleteDuplicates[coefficients] == 0]|>
];
Options[SimultaneousDlogSolve] = Options[SimultaneousDlogConditions];
SimultaneousDlogSolve[numerator_, cut_Association, parameters_List,
    OptionsPattern[]] := Module[{conditions, unknowns},
  conditions = SimultaneousDlogConditions[numerator, cut,
    ResidueSymbol -> OptionValue[ResidueSymbol]];
  If[conditions === $Failed || FailureQ[conditions], Return[conditions]];
  unknowns = DeleteDuplicates@Join[parameters, {conditions["ResidueSymbol"]}];
  Append[conditions, "Solutions" -> Quiet[
    Solve[conditions["Equations"], unknowns], Solve::svars]]
];
End[];
EndPackage[];
