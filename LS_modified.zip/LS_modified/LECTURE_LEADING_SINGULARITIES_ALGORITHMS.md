# Leading singularities 的递归、Gröbner 与素分解算法

## 1. 问题

考虑有理微分形式

\[
\Omega=N(z)\frac{dz_1\wedge\cdots\wedge dz_n}
{\prod_{\alpha=1}^{m}f_\alpha(z)^{a_\alpha}},
\]

其中 numerator 通常是带待定系数的有限次 polynomial ansatz。目标是：

1. 找到所有相关的多重留数；
2. 排除 double pole 和更高阶极点；
3. 求出使形式成为 dlog 型的 numerator 系数条件；
4. 判断 leading singularities 是否为常数或有理数。

必须区分两个问题：

- 零维孤立交点上的 Grothendieck point residue；
- 正维极点簇上的递归 residue、横截 residue 或进一步边界 residue。

正维理想本身没有唯一的 point residue，不能任意补充方程把它变成零维。

## 2. 版本一：原始 DlogBasis 递归算法

入口：

```wl
Get["01_Original_DlogBasis.wl"];
DlogBasis`LeadingSingularities[func, vars, c]
```

原始算法把 integrand 转换成内部 factor-list 表示，然后按变量顺序递归：

1. 选择当前变量；
2. 对该变量做 partial fraction 和 residue 分解；
3. 追踪剩余变量、已经选择的 pole 和不同 residue 分支；
4. 检测 double poles；
5. 若出现非 logarithmic pole，求 numerator 参数关系；
6. 把新关系代回所有尚未处理的分支；
7. 对平方根分支尝试变量变换和单独的 algebraic residue 处理；
8. 最后合并线性相关的 leading singularities 与参数规则。

优点：

- 能处理正维、退化分支、高阶极点和部分平方根；
- 不要求 denominator 构成 complete intersection；
- 是当前最完整的 fallback。

主要代价：

- 同一表达式会被多次 factor、collect 和检测 double pole；
- 分支数随变量和 denominator factors 快速增长；
- Mathematica 中的大规模代数整理可能成为瓶颈。

## 3. 版本二：缓存优化版

入口：

```wl
Get["02_Cached_DlogBasis.wl"];
LeadingSingularitiesOptimized[func, vars, c]
```

这个版本不改变 residue 顺序、变量变换、double-pole 条件或最终求解逻辑。
它只对两个确定性热点函数加入 memoization：

```wl
FactorCollect[term]
FindDoublePoles[term, vars, c]
```

缓存键使用 `HoldComplete`，每次顶层调用前清空。因此缓存：

- 只在一次 leading-singularity 计算内部共享；
- 不会污染下一个积分；
- 对相同输入严格复用相同输出；
- 不改变原算法的数学结果。

Sector 2047 的早期 benchmark 中约有 `1.27x` 加速，但实际收益依赖重复子表达式
数量。

## 4. 版本三：Singular 零维混合算法

入口：

```wl
Get["03_Singular_Hybrid.wl"];
LeadingSingularitiesSingular[func, vars, c]
```

### 4.1 denominator 分析

程序先提取 polynomial divisors，并记录每个 divisor 的幂。如果存在平方或更高次
divisor，返回 `HigherPowerDivisor`，交给递归算法施加 double-pole 条件。

### 4.2 Gröbner dimension

对

\[
I=\langle f_1,\ldots,f_m\rangle
\]

调用 Singular `std` 和 `dim`。若理想零维并且 divisor 数等于变量数，进入
complete-intersection fast path。

### 4.3 simultaneous residue 条件

定义 Jacobian

\[
J=\det\left(\frac{\partial f_i}{\partial z_j}\right).
\]

若 numerator 是 \(N\)，常数 residue 记作 \(\rho\)，则 dlog 条件写成

\[
\operatorname{NF}_I(N-\rho J)=0.
\]

Singular 计算 standard basis 和 normal form；对 normal form 的每个 monomial
系数置零，就得到 numerator 参数与 \(\rho\) 的线性方程。

这一步避免枚举每个代数根，也不调用 Mathematica `GroebnerBasis` 或
`PolynomialReduce`。

### 4.4 block 与 completion

`BlockVariables` 允许只对一组横截变量做消元，其余变量进入 Singular 的有理函数
系数域。`CompletionDivisors` 只能包含真实 denominator、无穷远边界或合法
blow-up exceptional divisor，不能为了得到零维而人为添加。

### 4.5 module-lift certificate

候选 numerator 可用

\[
N=\sum_i a_i f_i+bJ
\]

验证。Singular `lift` 返回显式系数矩阵，余项严格为零时才设置
`"Verified" -> True`。

## 5. 版本四：正维 prime-decomposition 混合算法

入口：

```wl
Get["04_Prime_Decomposition_Hybrid.wl"];
LeadingSingularitiesPrimeDecomposition[func, vars, c]
```

当理想正维或不是 complete intersection 时，当前版调用：

```singular
LIB "primdec.lib";
primdecGTZ(I);
```

GTZ 分解返回

\[
I=Q_1\cap\cdots\cap Q_s,\qquad \sqrt{Q_i}=P_i,
\]

其中 \(Q_i\) 是 primary component，\(P_i\) 是 associated prime。输出保存：

```wl
<|
  "Dimension" -> ...,
  "PrimaryIdeal" -> {...},
  "PrimeIdeal" -> {...}
|>
```

结果使用 divisor、变量和 monomial order 组成的精确键缓存。

### 5.1 已经获得的改进

- 把 reducible 正维 pole variety 分成不可约素分支；
- 区分各分支的维数和嵌入/primary 信息；
- 后续重复分析可以直接复用 decomposition；
- 能识别哪些分支可能使用 block residue，哪些必须继续递归；
- 避免对同一 reducible variety 反复做盲目的 factor/交点搜索。

例如

\[
\langle xy,xz\rangle
=\langle x\rangle\cap\langle y,z\rangle,
\]

对应一个二维分支和一个一维分支。

### 5.2 当前保守边界

prime decomposition 不会自动把正维分支变成 point residue。当前版本把分解结果
加入报告，然后仍由缓存版 DlogBasis 处理 unresolved components。

下一步安全优化应对每个 \(P_i\)：

1. 选择与 component 横截的变量块；
2. 验证局部 codimension 与独立 divisor 数一致；
3. 检查 Jacobian 在 generic point 是否非零；
4. 计算其余 denominator 在 quotient ring 中是否可逆；
5. 对简单横截分支生成 block normal-form 条件；
6. 对 higher multiplicity、嵌入分支和无穷远分支保留递归 fallback；
7. 先解出安全的线性参数约束，再把缩小后的 ansatz 交给 DlogBasis。

不能直接使用 prime generators 代替物理 denominator，因为这样可能改变 pole
multiplicity 和 contour。

## 6. 版本选择

| 情况 | 建议版本 |
|---|---|
| 需要最保守、最完整的递归结果 | 版本二 |
| 零维 polynomial complete intersection | 版本三或四 |
| 已知合法 completion/block | 版本三或四 |
| reducible 或正维 cut，需要研究分支结构 | 版本四 |
| higher-power divisor 或 radical | 版本四诊断后回退版本二 |

推荐默认使用版本四，并检查：

```wl
report["Status"]
report["Reason"]
report["PrimaryDecomposition"]
report["PrimeDimensions"]
report["DlogBasisResult"]
```

## 7. 正确性原则

1. numerator ansatz 必须声明有限次数上界；
2. exact algebra 使用有理数，避免 machine-real kinematics；
3. 正维 cut 不等同于 point residue；
4. completion divisor 必须有物理或几何来源；
5. per-loop dimensions 只是分析工具，候选要回到共同目标维数复核；
6. fast path 的候选应检查 module-lift certificate；
7. 新优化必须与原始 DlogBasis 做回归比较。

## 8. 测试

```bash
wolframscript -file ../test-singular-prime-decomposition.wl
wolframscript -file ../test-simultaneous-dlog.wl
wolframscript -file ../test-singular-completion.wl
wolframscript -file ../test-dlogbasis-singular-hybrid.wl
wolframscript -file ../test-baikov-singular-rational-ls.wl
wolframscript -file ../test-lbl-controls.wl
```

测试覆盖 prime decomposition、normal-form dlog 条件、completion、fallback、
module lift、Baikov workflow 和 LBL controls。

