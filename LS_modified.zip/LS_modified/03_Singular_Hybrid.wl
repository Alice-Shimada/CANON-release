(* Zero-dimensional Singular fast path with cached DlogBasis fallback.

   Canonical implementation:
   ../DlogBasisLeadingSingularitiesSingular.wl

   Public entry points:
     DlogBasisLeadingSingularitiesSingular`LeadingSingularitiesSingular[
       func, vars, coefficientHead]
     DlogBasisLeadingSingularitiesSingular`SingularLeadingSingularityAnalysis[
       func, vars]
*)

Get[FileNameJoin[{
  DirectoryName[DirectoryName[$InputFileName]],
  "DlogBasisLeadingSingularitiesSingular.wl"
}]];

