(* Conservative cached version of DlogBasis LeadingSingularities.

   Canonical implementation:
   ../DlogBasisLeadingSingularitiesCached.wl

   Public entry point:
     DlogBasisLeadingSingularitiesCached`LeadingSingularitiesOptimized[
       func, vars, coefficientHead]
*)

Get[FileNameJoin[{
  DirectoryName[DirectoryName[$InputFileName]],
  "DlogBasisLeadingSingularitiesCached.wl"
}]];

