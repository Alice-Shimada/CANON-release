# LeadingSingularities 修改版程序

本目录把当前使用过的四个 `LeadingSingularities` 版本集中为统一入口。
具体算法、差异和使用建议见
[`LECTURE_LEADING_SINGULARITIES_ALGORITHMS.md`](LECTURE_LEADING_SINGULARITIES_ALGORITHMS.md)。

| 文件 | 版本 |
|---|---|
| `01_Original_DlogBasis.wl` | 原始 DlogBasis 递归算法 |
| `02_Cached_DlogBasis.wl` | 单次调用缓存优化 |
| `03_Singular_Hybrid.wl` | 零维 Singular fast path 与递归 fallback |
| `04_Prime_Decomposition_Hybrid.wl` | 当前版：增加正维 GTZ prime decomposition |

这些文件是稳定入口；核心实现仍保存在上一级目录，避免重复代码在后续修改中
产生不一致。

