(* Conservative optimization for DlogBasis`LeadingSingularities.
   The residue algorithm and its iteration order are unchanged. *)

If[! MemberQ[$Packages, "DlogBasis`"],
  Get["/home/wuyu/package/DlogBasis-master/DlogBasis.wl"]
];

BeginPackage["DlogBasisLeadingSingularitiesCached`", {"DlogBasis`"}];

LeadingSingularitiesOptimized::usage =
  "LeadingSingularitiesOptimized[args] calls DlogBasis`LeadingSingularities with per-call caches for repeated algebraic normalization and double-pole tests.";
ClearLeadingSingularitiesCache::usage =
  "ClearLeadingSingularitiesCache[] clears all optimization caches.";
RestoreOriginalLeadingSingularities::usage =
  "RestoreOriginalLeadingSingularities[] removes the cache wrappers and restores the original private definitions.";

Begin["`Private`"];

$factorCache = <||>;
$poleCache = <||>;
$cacheHits = <|"FactorCollect" -> 0, "FindDoublePoles" -> 0|>;
$cacheMisses = <|"FactorCollect" -> 0, "FindDoublePoles" -> 0|>;

ClearLeadingSingularitiesCache[] := (
  $factorCache = <||>;
  $poleCache = <||>;
  $cacheHits = <|"FactorCollect" -> 0, "FindDoublePoles" -> 0|>;
  $cacheMisses = <|"FactorCollect" -> 0, "FindDoublePoles" -> 0|>;
  Null
);

LeadingSingularitiesOptimized[args___] := Module[{result},
  ClearLeadingSingularitiesCache[];
  result = DlogBasis`LeadingSingularities[args];
  result
];

End[];
EndPackage[];

Begin["DlogBasis`Private`"];

If[DownValues[FactorCollectUncached] === {},
  DownValues[FactorCollectUncached] =
    DownValues[FactorCollect] /. FactorCollect -> FactorCollectUncached
];
If[DownValues[FindDoublePolesUncached] === {},
  DownValues[FindDoublePolesUncached] =
    DownValues[FindDoublePoles] /. FindDoublePoles -> FindDoublePolesUncached
];

ClearAll[FactorCollect];
FactorCollect[term_] := Module[{key = HoldComplete[term], cache, value},
  cache = DlogBasisLeadingSingularitiesCached`Private`$factorCache;
  If[KeyExistsQ[cache, key],
    DlogBasisLeadingSingularitiesCached`Private`$cacheHits["FactorCollect"]++;
    cache[key],
    value = FactorCollectUncached[term];
    AssociateTo[DlogBasisLeadingSingularitiesCached`Private`$factorCache,
      key -> value];
    DlogBasisLeadingSingularitiesCached`Private`$cacheMisses["FactorCollect"]++;
    value
  ]
];

ClearAll[FindDoublePoles];
FindDoublePoles[term_, vars_, nn_] := Module[
  {key = HoldComplete[term, vars, nn], cache, value},
  cache = DlogBasisLeadingSingularitiesCached`Private`$poleCache;
  If[KeyExistsQ[cache, key],
    DlogBasisLeadingSingularitiesCached`Private`$cacheHits["FindDoublePoles"]++;
    cache[key],
    value = FindDoublePolesUncached[term, vars, nn];
    AssociateTo[DlogBasisLeadingSingularitiesCached`Private`$poleCache,
      key -> value];
    DlogBasisLeadingSingularitiesCached`Private`$cacheMisses["FindDoublePoles"]++;
    value
  ]
];

End[];

DlogBasisLeadingSingularitiesCached`RestoreOriginalLeadingSingularities[] := (
  DownValues[DlogBasis`Private`FactorCollect] =
    DownValues[DlogBasis`Private`FactorCollectUncached] /.
      DlogBasis`Private`FactorCollectUncached -> DlogBasis`Private`FactorCollect;
  DownValues[DlogBasis`Private`FindDoublePoles] =
    DownValues[DlogBasis`Private`FindDoublePolesUncached] /.
      DlogBasis`Private`FindDoublePolesUncached -> DlogBasis`Private`FindDoublePoles;
  DlogBasisLeadingSingularitiesCached`ClearLeadingSingularitiesCache[];
  Null
);

Print["Installed conservative cached LeadingSingularities optimization."];
