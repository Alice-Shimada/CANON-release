portableRoot = DirectoryName[DirectoryName[$InputFileName]];
Get[FileNameJoin[{portableRoot, "LeadingSingularitiesPortable.wl"}]];

LeadingSingularitiesPortable`LoadSingularHybrid[];

Clear[x, y, c0, c1];
func = (c0 + c1 x y)/((x^2 - 2) (y^2 - 3));

report =
  DlogBasisLeadingSingularitiesSingular`LeadingSingularitiesSingular[
    func, {x, y}
  ];

Print[InputForm[report]];

