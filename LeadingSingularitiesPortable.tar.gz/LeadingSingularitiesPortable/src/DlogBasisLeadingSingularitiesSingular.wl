(* ::Package:: *)

If[! MemberQ[$Packages, "DlogBasis`"],
  Get[FileNameJoin[{DirectoryName[DirectoryName[$InputFileName]],
    "vendor", "DlogBasis.wl"}]]];
Get[FileNameJoin[{DirectoryName[$InputFileName],
  "DlogBasisLeadingSingularitiesCached.wl"}]];
Get[FileNameJoin[{DirectoryName[$InputFileName],
  "SimultaneousDlogResidues.wl"}]];

BeginPackage["DlogBasisLeadingSingularitiesSingular`", {
  "DlogBasis`", "DlogBasisLeadingSingularitiesCached`",
  "SimultaneousDlogResidues`"}];

LeadingSingularitiesSingular::usage =
  "LeadingSingularitiesSingular[func,vars,head] tries a Singular simultaneous or block cut first and automatically falls back to cached DlogBasis LeadingSingularities.";
SingularLeadingSingularityAnalysis::usage =
  "SingularLeadingSingularityAnalysis[func,vars] analyzes divisors, dimension, completions and simultaneous dlog conditions without invoking DlogBasis fallback.";
CutDivisors::usage = "Option specifying cut divisors; Automatic extracts polynomial denominator factors.";
CompletionDivisors::usage = "Option specifying legitimate extra divisors for zero-dimensional completion.";
BlockVariables::usage = "Option selecting variables eliminated together; remaining variables become Singular coefficient-field parameters.";
MaxCompletions::usage = "Maximum number of zero-dimensional completions retained.";
VerifyFastPath::usage = "If True, also evaluate the original cached DlogBasis algorithm on a Singular fast path.";
PrimeDecomposition::usage = "If True, compute a cached Singular GTZ primary decomposition when the cut is non-zero-dimensional or is not a complete intersection.";

Begin["`Private`"];

Clear[automaticDivisors];
automaticDivisors[func_, vars_List] := Module[{den, factors},
  den = Denominator[Together[func]];
  If[! PolynomialQ[den, vars], Return[{}]];
  factors = If[Head[Factor[den]] === Times, List @@ Factor[den], {Factor[den]}];
  DeleteDuplicates@Cases[factors, factor_ /; ! FreeQ[factor, Alternatives @@ vars] :>
    If[MatchQ[factor, Power[_, _Integer?Positive]],
      <|"Divisor" -> factor[[1]], "Power" -> factor[[2]]|>,
      <|"Divisor" -> factor, "Power" -> 1|>]]
];

Clear[makeAnalysis];
Options[makeAnalysis] = {
  CutDivisors -> Automatic, CompletionDivisors -> {},
  BlockVariables -> Automatic, MonomialOrder -> "dp",
  MaxCompletions -> 16, PrimeDecomposition -> True};

makeAnalysis[func_, vars_List, OptionsPattern[]] := Module[
  {factorData, divisors, powers, block, baseDim, completions = {}, chosen,
   cut, effectiveNumerator, conditions, reason = None, decomposition},
  block = Replace[OptionValue[BlockVariables], Automatic -> vars];
  factorData = If[OptionValue[CutDivisors] === Automatic,
    automaticDivisors[func, block],
    <|"Divisor" -> #, "Power" -> 1|> & /@ OptionValue[CutDivisors]];
  divisors = Lookup[factorData, "Divisor", {}];
  powers = Lookup[factorData, "Power", {}];
  If[divisors === {},
    Return[<|"Status" -> "Fallback", "Reason" -> "NoPolynomialDivisors",
      "BlockVariables" -> block|>]];
  If[AnyTrue[powers, # =!= 1 &],
    Return[<|"Status" -> "Fallback", "Reason" -> "HigherPowerDivisor",
      "Divisors" -> divisors, "Powers" -> powers,
      "BlockVariables" -> block|>]];
  baseDim = SingularIdealDimension[divisors, block,
    MonomialOrder -> OptionValue[MonomialOrder]];
  If[baseDim === $Failed,
    Return[<|"Status" -> "Fallback", "Reason" -> "SingularDimensionFailed",
      "Divisors" -> divisors|>]];
  chosen = divisors;
  If[baseDim > 0 && OptionValue[CompletionDivisors] =!= {},
    completions = FindZeroDimensionalCompletions[divisors,
      OptionValue[CompletionDivisors], block,
      MonomialOrder -> OptionValue[MonomialOrder],
      MaxCompletions -> OptionValue[MaxCompletions]];
    If[completions =!= {} && Length[First[completions]] + Length[divisors] ==
        Length[block], chosen = Join[divisors, First[completions]]]];
  If[Length[chosen] =!= Length[block],
    reason = If[baseDim > 0, "NonZeroDimensionalCut", "NotCompleteIntersection"];
    decomposition = If[TrueQ[OptionValue[PrimeDecomposition]],
      SingularPrimaryDecomposition[divisors, block,
        MonomialOrder -> OptionValue[MonomialOrder]],
      Missing["NotRequested"]];
    Return[<|"Status" -> "Fallback", "Reason" -> reason,
      "Dimension" -> baseDim, "Divisors" -> divisors,
      "Completions" -> completions, "BlockVariables" -> block,
      "PrimaryDecomposition" -> decomposition,
      "PrimeDimensions" -> If[ListQ[decomposition],
        Lookup[decomposition, "Dimension"], Missing["Unavailable"]]|>]];
  cut = PrepareDlogCut[chosen, block,
    MonomialOrder -> OptionValue[MonomialOrder]];
  If[cut === $Failed,
    Return[<|"Status" -> "Fallback", "Reason" -> "PrepareCutFailed",
      "Dimension" -> baseDim, "Divisors" -> chosen|>]];
  effectiveNumerator = Together[func Times @@ chosen];
  If[! FreeQ[Denominator[effectiveNumerator], Alternatives @@ block],
    Return[<|"Status" -> "Fallback", "Reason" -> "UnmatchedDenominator",
      "Divisors" -> chosen, "EffectiveNumerator" -> effectiveNumerator|>]];
  conditions = SimultaneousDlogConditions[effectiveNumerator, cut];
  If[conditions === $Failed || FailureQ[conditions],
    Return[<|"Status" -> "Fallback", "Reason" -> "SingularReduceFailed",
      "Divisors" -> chosen|>]];
  <|"Status" -> "SingularFastPath", "Backend" -> "Singular",
    "Dimension" -> 0, "OriginalDimension" -> baseDim,
    "Divisors" -> chosen, "Completions" -> completions,
    "BlockVariables" -> block, "CutData" -> cut,
    "EffectiveNumerator" -> effectiveNumerator,
    "DlogConditions" -> conditions|>
];

Options[SingularLeadingSingularityAnalysis] = Options[makeAnalysis];
SingularLeadingSingularityAnalysis[func_, vars_List, OptionsPattern[]] :=
  makeAnalysis[func, vars,
    CutDivisors -> OptionValue[CutDivisors],
    CompletionDivisors -> OptionValue[CompletionDivisors],
    BlockVariables -> OptionValue[BlockVariables],
    MonomialOrder -> OptionValue[MonomialOrder],
    MaxCompletions -> OptionValue[MaxCompletions],
    PrimeDecomposition -> OptionValue[PrimeDecomposition]];

Options[LeadingSingularitiesSingular] = Join[Options[makeAnalysis],
  {VerifyFastPath -> False}];

LeadingSingularitiesSingular[func_, vars_List, head_, OptionsPattern[]] := Module[
  {analysis, fallback = Missing["NotRun", "SingularFastPath"]},
  analysis = makeAnalysis[func, vars,
    CutDivisors -> OptionValue[CutDivisors],
    CompletionDivisors -> OptionValue[CompletionDivisors],
    BlockVariables -> OptionValue[BlockVariables],
    MonomialOrder -> OptionValue[MonomialOrder],
    MaxCompletions -> OptionValue[MaxCompletions],
    PrimeDecomposition -> OptionValue[PrimeDecomposition]];
  If[analysis["Status"] =!= "SingularFastPath" || TrueQ[OptionValue[VerifyFastPath]],
    fallback = DlogBasisLeadingSingularitiesCached`LeadingSingularitiesOptimized[
      func, vars, head]];
  Append[analysis, "DlogBasisResult" -> fallback]
];

LeadingSingularitiesSingular[func_, vars_List, OptionsPattern[]] := Module[
  {analysis, fallback = Missing["NotRun", "SingularFastPath"]},
  analysis = makeAnalysis[func, vars,
    CutDivisors -> OptionValue[CutDivisors],
    CompletionDivisors -> OptionValue[CompletionDivisors],
    BlockVariables -> OptionValue[BlockVariables],
    MonomialOrder -> OptionValue[MonomialOrder],
    MaxCompletions -> OptionValue[MaxCompletions],
    PrimeDecomposition -> OptionValue[PrimeDecomposition]];
  If[analysis["Status"] =!= "SingularFastPath" || TrueQ[OptionValue[VerifyFastPath]],
    fallback = DlogBasisLeadingSingularitiesCached`LeadingSingularitiesOptimized[
      func, vars]];
  Append[analysis, "DlogBasisResult" -> fallback]
];

End[];
EndPackage[];
