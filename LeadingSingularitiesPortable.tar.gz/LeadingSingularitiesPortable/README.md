# Portable LeadingSingularities

这是一个可复制到其他电脑独立使用的 `LeadingSingularities` 程序包。源码中没有
`/home/wuyu/...` 绝对路径。

## 包含的版本

1. 原始 DlogBasis 递归算法；
2. 缓存版 DlogBasis；
3. Singular 零维 Gröbner fast path；
4. 带 GTZ primary/prime decomposition 的当前混合版。

原始 DlogBasis 源码完整保存在 `vendor/DlogBasis.wl`，因此无需在目标电脑另行
下载 DlogBasis。

## 系统依赖

- Wolfram Language/Mathematica，提供 `wolframscript`；
- Singular，命令名通常为 `Singular`。

Singular 是平台相关的原生程序，因此没有把某一台 Linux 机器上的二进制文件硬拷贝
进本目录。请使用目标系统的包管理器安装：

```bash
# Ubuntu/Debian
sudo apt-get install singular

# Conda
conda install -c conda-forge singular
```

如果 Singular 不在 `PATH` 中，设置：

```bash
export SINGULAR_EXECUTABLE=/absolute/path/to/Singular
```

原始版和缓存版不需要 Singular；Gröbner、module-lift 和 prime-decomposition
功能需要 Singular。

## 使用

```wl
Get["/path/to/LeadingSingularitiesPortable/LeadingSingularitiesPortable.wl"];

LeadingSingularitiesPortable`DependencyReport[]
```

### 原始版

```wl
LeadingSingularitiesPortable`LoadOriginal[];
DlogBasis`LeadingSingularities[func, vars, c]
```

### 缓存版

```wl
LeadingSingularitiesPortable`LoadCached[];
DlogBasisLeadingSingularitiesCached`LeadingSingularitiesOptimized[
  func, vars, c
]
```

### 当前 Singular 混合版

```wl
LeadingSingularitiesPortable`LoadSingularHybrid[];
DlogBasisLeadingSingularitiesSingular`LeadingSingularitiesSingular[
  func, vars, c
]
```

正维分解：

```wl
SimultaneousDlogResidues`SingularPrimaryDecomposition[
  divisors, vars
]
```

## 测试

从任意工作目录运行：

```bash
wolframscript -file /path/to/LeadingSingularitiesPortable/run_tests.wl
```

## 目录

```text
LeadingSingularitiesPortable/
├── LeadingSingularitiesPortable.wl
├── README.md
├── run_tests.wl
├── examples/
│   └── basic.wl
├── src/
│   ├── DlogBasisLeadingSingularitiesCached.wl
│   ├── DlogBasisLeadingSingularitiesSingular.wl
│   └── SimultaneousDlogResidues.wl
├── tests/
│   ├── original_and_cached.wl
│   └── smoke.wl
└── vendor/
    ├── DlogBasis.wl
    └── DLOGBASIS_UPSTREAM_README.md
```

## 外部可选依赖

上游 `DlogBasis.wl` 中另有一个 Macaulay2 辅助路径，但本目录涉及的
`LeadingSingularities`、缓存、Singular normal form、module lift 和 GTZ 分解
均不调用它。只有主动使用对应的上游因式分解辅助函数时才需要额外配置
Macaulay2。

