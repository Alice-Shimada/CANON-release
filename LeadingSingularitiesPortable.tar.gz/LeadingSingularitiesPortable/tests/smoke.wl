portableRoot = DirectoryName[DirectoryName[$InputFileName]];
Get[FileNameJoin[{portableRoot, "LeadingSingularitiesPortable.wl"}]];

deps = LeadingSingularitiesPortable`DependencyReport[];
LeadingSingularitiesPortable`LoadSingularHybrid[];

Clear[x, y, z, c0, c1];

fast =
  DlogBasisLeadingSingularitiesSingular`LeadingSingularitiesSingular[
    (c0 + c1 x y)/((x^2 - 2) (y^2 - 3)), {x, y}
  ];

prime =
  SimultaneousDlogResidues`SingularPrimaryDecomposition[
    {x y, x z}, {x, y, z}
  ];

passed =
  TrueQ[deps["VendoredDlogBasis"]] &&
  TrueQ[deps["SingularAvailable"]] &&
  fast["Status"] === "SingularFastPath" &&
  Sort[Lookup[prime, "Dimension"]] === {1, 2};

Print[InputForm[
  <|"Dependencies" -> deps, "FastStatus" -> fast["Status"],
    "PrimeDimensions" -> Lookup[prime, "Dimension"],
    "Passed" -> passed|>
]];

If[! passed, Exit[1]];

