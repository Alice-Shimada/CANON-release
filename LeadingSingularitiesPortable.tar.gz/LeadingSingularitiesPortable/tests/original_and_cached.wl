portableRoot = DirectoryName[DirectoryName[$InputFileName]];
Get[FileNameJoin[{portableRoot, "LeadingSingularitiesPortable.wl"}]];

LeadingSingularitiesPortable`LoadCached[];

Clear[x, c];
func = c[1]/x;

original = DlogBasis`LeadingSingularities[func, {x}, c];
cached =
  DlogBasisLeadingSingularitiesCached`LeadingSingularitiesOptimized[
    func, {x}, c
  ];

passed = SameQ[original, cached];
Print[InputForm[
  <|"Original" -> original, "Cached" -> cached, "Passed" -> passed|>
]];
If[! passed, Exit[1]];

