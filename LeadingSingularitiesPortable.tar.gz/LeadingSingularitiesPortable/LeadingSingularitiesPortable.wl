(* Portable unified loader for all LeadingSingularities implementations. *)

BeginPackage["LeadingSingularitiesPortable`"];

LoadOriginal::usage =
  "LoadOriginal[] loads the upstream recursive DlogBasis implementation.";
LoadCached::usage =
  "LoadCached[] loads the conservative per-call cached implementation.";
LoadSingularHybrid::usage =
  "LoadSingularHybrid[] loads the Singular fast path, prime decomposition, and cached fallback.";
DependencyReport::usage =
  "DependencyReport[] reports Wolfram Language and Singular availability.";

Begin["`Private`"];

$PackageRoot = DirectoryName[$InputFileName];
$VendorRoot = FileNameJoin[{$PackageRoot, "vendor"}];
$SourceRoot = FileNameJoin[{$PackageRoot, "src"}];

LoadOriginal[] := (
  If[! MemberQ[$Packages, "DlogBasis`"],
    Get[FileNameJoin[{$VendorRoot, "DlogBasis.wl"}]]];
  DlogBasis`LeadingSingularities
);

LoadCached[] := (
  LoadOriginal[];
  If[! MemberQ[$Packages, "DlogBasisLeadingSingularitiesCached`"],
    Get[FileNameJoin[{$SourceRoot,
      "DlogBasisLeadingSingularitiesCached.wl"}]]];
  DlogBasisLeadingSingularitiesCached`LeadingSingularitiesOptimized
);

LoadSingularHybrid[] := (
  LoadCached[];
  If[! MemberQ[$Packages, "DlogBasisLeadingSingularitiesSingular`"],
    Get[FileNameJoin[{$SourceRoot,
      "DlogBasisLeadingSingularitiesSingular.wl"}]]];
  DlogBasisLeadingSingularitiesSingular`LeadingSingularitiesSingular
);

DependencyReport[] := Module[{configured, probe, singular, available},
  configured = Quiet@Environment["SINGULAR_EXECUTABLE"];
  singular = If[StringQ[configured] && StringLength[configured] > 0,
    configured, "Singular"];
  available = If[singular =!= "Singular",
    FileExistsQ[singular],
    probe = Quiet@Check[
      If[$OperatingSystem === "Windows",
        RunProcess[{"where", "Singular"}],
        RunProcess[{"sh", "-c", "command -v Singular"}]
      ],
      $Failed
    ];
    AssociationQ[probe] && Lookup[probe, "ExitCode", 1] === 0
  ];
  <|
    "WolframVersion" -> $Version,
    "WolframVersionNumber" -> $VersionNumber,
    "PackageRoot" -> $PackageRoot,
    "VendoredDlogBasis" ->
      FileExistsQ[FileNameJoin[{$VendorRoot, "DlogBasis.wl"}]],
    "SingularExecutable" -> singular,
    "SingularAvailable" -> available
  |>
];

End[];
EndPackage[];
