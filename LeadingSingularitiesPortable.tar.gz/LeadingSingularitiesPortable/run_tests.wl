root = DirectoryName[$InputFileName];
tests = {
  FileNameJoin[{root, "tests", "original_and_cached.wl"}],
  FileNameJoin[{root, "tests", "smoke.wl"}]
};

Do[
  Print["Running ", test];
  result = RunProcess[{"wolframscript", "-file", test}];
  Print[result["StandardOutput"]];
  If[result["ExitCode"] =!= 0,
    Print[result["StandardError"]];
    Exit[result["ExitCode"]]
  ],
  {test, tests}
];

Print["All portable LeadingSingularities tests passed."];

